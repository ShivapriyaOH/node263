console.log("Hello World");

